img_rows, img_cols = 64, 64
channel = 3
batch_size = 1
epochs = 50
patience = 50
num_train_samples = 10
num_valid_samples = 10
num_classes = 313
kernel = 3
weight_decay = 1e-3
epsilon = 1e-8
nb_neighbors = 5
# temperature parameter T
T = 0.38
