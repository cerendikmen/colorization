img_rows, img_cols = 32, 32
channel = 3
batch_size = 10
epochs = 5
patience = 50
num_train_samples = 40
num_valid_samples = 10
num_classes = 241
kernel = 3
weight_decay = 1e-3
epsilon = 1e-8
nb_neighbors = 5
# temperature parameter T
T = 0.38
